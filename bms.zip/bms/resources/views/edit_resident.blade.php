<form autocomplete="off">
    @foreach($data as $datas)
    <div class="container d-flex flex-row">
    <div class="pl-2 w-50">
      @csrf
        <div class="form-group">
          <label for="recipient-name" class="col-form-label">Household No.:</label>
          <input type="text" id="edit_hn" class="form-control" value="{{$datas->household_no}}" id="household" required>
        </div>
        <div class="form-group">
            <label for="recipient-name" class="col-form-label">Fullname:</label>
            <input type="text" id="edit_fullname" class="form-control" id="fullname"  value="{{$datas->fullname}}" required>
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Birthdate:</label>
            <input type="date" id="edit_bdate" class="form-control" id="bdate"  value="{{$datas->bdate}}" required>
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Age:</label>
            <input type="number" id="edit_age" class="form-control"  value="{{$datas->age}}" id="age" required>
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Civil Status:</label>
            <select id="edit_civil" class="form-control" required>
             @foreach($civil_status as $civil)
              <option value="{{$civil->civil_status}}" {{$datas->civil_status == $civil->civil_status ? 'selected':''}}>{{$civil->civil_status}}</option>
              @endforeach
            </select>
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Religion:</label>
            <input type="text" id="edit_religion" class="form-control"  value="{{$datas->religion}}" id="religion" required>
          </div>
    </div>
    <div class="pl-2 w-50">
      <div class="form-group">
        <label for="recipient-name" class="col-form-label">BirthPlace:</label>
        <input type="text" id="edit_bplace" class="form-control"  value="{{$datas->bplace}}" id="bplace" required>
      </div>
      <div class="form-group">
          <label for="recipient-name" class="col-form-label">Voter:</label>
          <select id="edit_voter" class="form-control" required>
            @foreach($voter as $voters)
              <option value="{{$voters->is_voters}}" {{$datas->voter == $voters->is_voters ? 'selected': ''}}>{{$voters->is_voters}}</option>
            @endforeach
          </select>
        </div>
        <div class="form-group">
          <label for="recipient-name" class="col-form-label">Benefits:</label>
          <input type="text" id="edit_benefits" class="form-control"  value="{{$datas->benefits}}" id="benefits" required>
        </div>
        <div class="form-group">
          <label for="recipient-name" class="col-form-label">Annual:</label>
          <input type="number" id="edit_annual" class="form-control"  value="{{$datas->annual}}" id="annual" required>
        </div>
        <div class="form-group">
          <label for="recipient-name" class="col-form-label">Occupation:</label>
          <input type="text" id="edit_work" class="form-control"  value="{{$datas->work}}" id="occupation" required>
        </div>
        <div class="form-group">
          <label for="recipient-name" class="col-form-label">Status:</label>
          <select  id="edit_status" class="form-control" required >
            <@foreach($stat as $status)
                <option value="{{$status->is_status}}" {{$datas->status == $status->is_status ? 'selected':''}}>{{$status->is_status}}</option>
            @endforeach
          </select>
      </div>
      @endforeach
</form>