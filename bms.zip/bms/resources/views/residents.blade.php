@extends('layouts.app')

@section('content')
<div class="container-fluid mr-2">
       <a href="/residents/add" id="btnAddRes" style="float: right;" class="text-white btn btn-primary mb-2"><i class="fa fa-plus"></i>&nbsp;Add New Resident</a>
       <table class="table mt-2" id="tbl_residents">
        <thead class="thead-light">
          <tr>
            <th class="text-center">#</th>
            <th class="text-center">Household No.</th>
            <th class="text-center">Fullname</th>
            <th class="text-center">Birthdate</th>
            <th class="text-center">Age</th>
            <th class="text-center">Civil Status</th>
            <th class="text-center">Religion</th>
            <th class="text-center">BirthPlace</th>
            <th class="text-center">Registered Voter</th>
            <th class="text-center">Benefits</th>
            <th class="text-center">Annual</th>
            <th class="text-center">Work</th>
            <th class="text-center">Status</th>
            <th class="text-center">Action</th>
          </tr>
        </thead>
        @foreach ($resident as $residents)
        <tbody>
          <tr>
            <td class="text-center">{{ $residents->id}}</td>
            <td class="text-center">{{ $residents->household_no}}</td>
            <td class="text-center">{{ $residents->fullname }}</td>
            <td class="text-center">{{ $residents->bdate }}</td>
            <td class="text-center">{{ $residents->age }}</td>
            <td class="text-center">{{ $residents->civil_status }}</td>
            <td class="text-center">{{ $residents->religion }}</td>
            <td class="text-center">{{ $residents->bplace }}</td>
            <td class="text-center">{{ $residents->voter }}</td>
            <td class="text-center">{{ $residents->benefits }}</td>
            <td class="text-center">{{ $residents->annual }}</td>
            <td class="text-center">{{ $residents->work }}</td>
            <td class="text-center">{{ $residents->status }}</td>
            <td class="text-center">
              <a href="/residents/show/{{ $residents->id}}"><i class="fa fa-upload text-default mr-3"  style="cursor: pointer;"></i></a>
            </td>
            
          </tr>
        </tbody>
        @endforeach
      </table>
</div>
@endsection

{{-- <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script> --}}


