@extends('layouts.app')

@section('content')
<div class="container">
       <table class="table mt-2 table-bordered">
        <thead class="thead-light">
          <tr>
            <th class="text-center">Names</th>
            <th class="text-center">Age</th>
            <th class="text-center">Designation</th>
            <th class="text-center">Job Position</th>
            <th class="text-center">Start Term</th>
            <th class="text-center">End Term</th>
          </tr>
        </thead>
        <tbody>
          @foreach($official as $officials)
            <tr>
              <th class="text-center">{{$officials->fullname}}</th>
              <td class="text-center">{{$officials->age}}</td>
              <td class="text-center">{{$officials->designation}}</td>
              <td class="text-center">{{$officials->job_position}}</td>
              <td class="text-center">{{$officials->start_term}}</td>
              <td class="text-center">{{$officials->end_term}}</td>
            </tr>
          @endforeach
        </tbody>
      </table>
      <div class="d-flex flex-row">
        <div class="card mt-1 mb-4 mx-4" style="width: 14rem; height:10rem;">
            <div class="card-body">
              <h5 class="card-title text-center mt-3">Total No. of Population</h5>
              <p class="card-text text-center text-danger font-weight-bold" style="font-size:1.5rem;">{{$countPopulation->count()}}</p>
            </div>
          </div>
          <div class="card mt-1 mb-4 mx-4" style="width: 14rem; height:10rem;">
            <div class="card-body">
              <h5 class="card-title text-center mt-3">Total No. of Registered Voters</h5>
              <p class="card-text text-center text-danger font-weight-bold" style="font-size:1.5rem;">{{$countVoters->count()}}</p>
            </div>
          </div>
          <div class="card mt-1 mb-42 mx-4" style="width: 14rem; height:10rem;">
            <div class="card-body">
              <h5 class="card-title text-center mt-3">Total No. of Senior Citizens</h5>
              <p class="card-text text-center text-danger font-weight-bold" style="font-size:1.5rem;">{{$countSeniors->count()}}</p>
            </div>
          </div>
          <div class="card mt-1 mb-4 mx-4" style="width: 14rem; height:10rem;">
            <div class="card-body">
              <h5 class="card-title text-center mt-3">Total No. of Indigenous People</h5>
              <p class="card-text text-center text-danger font-weight-bold" style="font-size:1.5rem;">{{$countIndigent->count()}}</p>
            </div>
          </div>
          <div class="card mt-1 mb-4 mx-4" style="width: 14rem; height:10rem;">
            <div class="card-body">
              <h5 class="card-title text-center mt-3">Total No. of Deceased</h5>
              <p class="card-text text-center text-danger font-weight-bold" style="font-size:1.5rem;">{{$countDeceased->count()}}</p>
            </div>
          </div>
      </div>
      
</div>
@endsection
