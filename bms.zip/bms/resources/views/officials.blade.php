@extends('layouts.app')

@section('content')
<div class="container">
       <button id="btnAddRes" style="float: right;" data-toggle="modal" data-target="#officialsModal" class="text-white btn btn-primary mb-2"><i class="fa fa-plus"></i>&nbsp;Add New Brgy.Officials</button>
       <table class="table mt-2" id="tbl_residents">
        <thead class="thead-light">
          <tr>
            <th>#</th>
            <th>Names</th>
            <th>Age</th>
            <th>Designation</th>
            <th>Job Position</th>
            <th>Start Term</th>
            <th>End Term</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th scope="row">1</th>
            <td>Mark</td>
            <td>Otto</td>
            <td>Otto</td>
            <td>Otto</td>
            <td>@mdo</td>
          </tr>
          <tr>
            <th scope="row">2</th>
            <td>Jacob</td>
            <td>Thornton</td>
            <td>Thornton</td>
            <td>Thornton</td>
            <td>@fat</td>
          </tr>
          <tr>
            <th scope="row">3</th>
            <td>Larry</td>
            <td>the Bird</td>
            <td>the Bird</td>
            <td>the Bird</td>
            <td>@twitter</td>
          </tr>
        </tbody>
      </table>
</div>

<!-- Modal Add Officials-->
<div class="modal fade bd-example-modal-lg" id="officialsModal"tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                  <h5 class="modal-title text-white" id="exampleModalLabel"><i class="fa fa-plus"></i>&nbsp;New Brgy.Officials</h5>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body d-flex flex-row">
          <div class="pl-3 w-50">
            <form>
              <div class="form-group">
                <label for="recipient-name" class="col-form-label">Household No.:</label>
                <input type="text" class="form-control" id="recipient-name">
              </div>
              <div class="form-group">
                  <label for="recipient-name" class="col-form-label">Fullname:</label>
                  <input type="text" class="form-control" id="recipient-name">
                </div>
                <div class="form-group">
                  <label for="recipient-name" class="col-form-label">Birthdate:</label>
                  <input type="text" class="form-control" id="recipient-name">
                </div>
                <div class="form-group">
                  <label for="recipient-name" class="col-form-label">Age:</label>
                  <input type="text" class="form-control" id="recipient-name">
                </div>
            </form>
          </div>
          <div class="pl-2 w-50">
            <div class="form-group">
              <label for="recipient-name" class="col-form-label">Religion:</label>
              <input type="text" class="form-control" id="recipient-name">
            </div>
            <div class="form-group">
                <label for="recipient-name" class="col-form-label">Voter:</label>
                <input type="text" class="form-control" id="recipient-name">
              </div>
              <div class="form-group">
                <label for="recipient-name" class="col-form-label">Benefits:</label>
                <input type="text" class="form-control" id="recipient-name">
              </div>
          </div>
        </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-primary"><i class="fa fa-save"></i>&nbsp;Save Brgy.Officials</button>
          </div>
      </div>
</div>
@endsection

<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script>
  $(document).ready(function(){
     //$('#tbl_residents').DataTable();

  })

</script>
