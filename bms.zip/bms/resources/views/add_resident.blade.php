@extends('layouts.app')

@section('content')
<form autocomplete="off">
<div class="container d-flex flex-row">
<div class="pl-2 w-50">
  @csrf
    <div class="form-group">
      <label for="recipient-name" class="col-form-label">Household No.:</label>
      <input type="text" class="form-control" id="household" required>
    </div>
    <div class="form-group">
        <label for="recipient-name" class="col-form-label">Fullname:</label>
        <input type="text" class="form-control" id="fullname" required>
      </div>
      <div class="form-group">
        <label for="recipient-name" class="col-form-label">Birthdate:</label>
        <input type="date" class="form-control" id="bdate" required>
      </div>
      <div class="form-group">
        <label for="recipient-name" class="col-form-label">Age:</label>
        <input type="number" class="form-control" id="age" required>
      </div>
      <div class="form-group">
        <label for="recipient-name" class="col-form-label">Civil Status:</label>
        <select id="civil" class="form-control" required>
          <option value="">--Select--</option>
          <option value="Single">Single</option>
          <option value="Married">Married</option>
          <option value="Separated">Separated</option>
          <option value="Widowed">Widowed</option>
          <option value="Live-In">Live-In</option>
        </select>
      </div>
      <div class="form-group">
        <label for="recipient-name" class="col-form-label">Religion:</label>
        <input type="text" class="form-control" id="religion" required>
      </div>
</div>
<div class="pl-2 w-50">
  <div class="form-group">
    <label for="recipient-name" class="col-form-label">BirthPlace:</label>
    <input type="text" class="form-control" id="bplace" required>
  </div>
  <div class="form-group">
      <label for="recipient-name" class="col-form-label">Voter:</label>
      <select id="voter" class="form-control" required>
        <option value="">--Select--</option>
        <option value="Y">Yes</option>
        <option value="N">No</option>
      </select>
    </div>
    <div class="form-group">
      <label for="recipient-name" class="col-form-label">Benefits:</label>
      <input type="text" class="form-control" id="benefits" required>
    </div>
    <div class="form-group">
      <label for="recipient-name" class="col-form-label">Annual:</label>
      <input type="number" class="form-control" id="annual" required>
    </div>
    <div class="form-group">
      <label for="recipient-name" class="col-form-label">Occupation:</label>
      <input type="text" class="form-control" id="occupation" required>
    </div>
    <div class="form-group">
      <label for="recipient-name" class="col-form-label">Status:</label>
      <select  id="status" class="form-control" required >
        <option value="">--Select--</option>
        <option value="L">Living</option>
        <option value="M">Migrate</option>
        <option value="D">Deceased</option>
      </select>
  </div>
  <button id="btnSaveResident" type="button" class="btn btn-primary mb-2" style="float:right;"><i class="fa fa-save"></i>&nbsp;Save Resident</button>
  <a href="/residents" id="btnAddRes" style="float: right;" class="text-white btn btn-primary mb-2 mr-2"><i class="fa fa-arrow-left"></i>&nbsp;View Resident List</a>
</form>
  <div>
  @endsection
