<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddCivilStatus extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::table('civil__statuses')->insert([
            ['civil_status' => 'Single'],
            ['civil_status' => 'Married'],
            ['civil_status' => 'Separated'],
            ['civil_status' => 'Widowed'],
            ['civil_status' => 'Live-In'],
        ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
