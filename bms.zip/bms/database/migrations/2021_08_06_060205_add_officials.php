<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddOfficials extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        DB::table('officials')->insert([
            ['fullname' => 'Mariano Reyes', 'age' => 50, 'designation'=>'None', 'job_position'=>'Captain','start_term'=>'05/22/2016','end_term'=>'05/25/2022'],
            ['fullname' => 'Julie Dela Cruz', 'age' => 45, 'designation'=>'Committee on Health', 'job_position'=>'Councilor 1','start_term'=>'05/22/2016','end_term'=>'05/25/2022'],
            ['fullname' => 'Jose Elmundo', 'age' => 34, 'designation'=>'Committee on Agriculture', 'job_position'=>'Councilor 2','start_term'=>'05/22/2016','end_term'=>'05/25/2022'],
            ['fullname' => 'Rosana Cruz', 'age' => 28, 'designation'=>'Committee on Finance', 'job_position'=>'Councilor 3','start_term'=>'05/22/2016','end_term'=>'05/25/2022'],
            ['fullname' => 'Victor Barcelon', 'age' => 55, 'designation'=>'Committee on Sports', 'job_position'=>'Councilor 4','start_term'=>'05/22/2016','end_term'=>'05/25/2022'],
            ['fullname' => 'Charrish Diaz', 'age' => 32, 'designation'=>'Committee on Education', 'job_position'=>'Councilor 5','start_term'=>'05/22/2016','end_term'=>'05/25/2022'],
            ['fullname' => 'Kristine Morano', 'age' => 30, 'designation'=>'Committee on Agriculture', 'job_position'=>'Councilor 6','start_term'=>'05/22/2016','end_term'=>'05/25/2022'],
            ['fullname' => 'Julius Abrea', 'age' => 49, 'designation'=>'Committee on Peace and Order', 'job_position'=>'Councilor 7','start_term'=>'05/22/2016','end_term'=>'05/25/2022'],
            ['fullname' => 'Juvie Abrea', 'age' => 19, 'designation'=>'None', 'job_position'=>'Sk.Chairperson','start_term'=>'05/22/2016','end_term'=>'05/25/2022'],
        ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
