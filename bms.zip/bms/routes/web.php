<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});

Auth::routes();

//Routes for Authentication
Route::get('/dashboard', 'HomeController@index')->name('dashboard');

//Routes for dashboard
Route::get('/dashboard', 'bmisController@index')->name('dashboard');

//Routes for residents
Route::get('/residents', 'residentController@index')->name('residents');
Route::get('/residents/add', 'residentController@create');
Route::post('/residents/save', 'residentController@store');
Route::get('/residents/show/{id}', 'residentController@show');
Route::get('/residents/edit/{id}', 'residentController@edit');
Route::put('/residents/update', 'residentController@update');
Route::get('/residents/delete/{id}', 'residentController@deleteById');
Route::delete('/residents/confirm-delete', 'residentController@confirmDelete');


//Routes for brgy officials
// Route::get('/officials', 'officialsController@index')->name('officials');
