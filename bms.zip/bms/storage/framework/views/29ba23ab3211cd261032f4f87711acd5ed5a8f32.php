<form>
    <input type="hidden" value="<?php echo e($id); ?>" id="delete_id">
    <div class="container">
        <h3>Are you sure you want to delete this data?</h3>
    </div>
    <button type="button" id="btnConfirmDeleteResident" style="outline:none; float:right;" class="btn btn-primary mt-2">Yes</button>
    <button type="button" style="outline:none; float:right;" class="btn btn-danger mr-2 mt-2" data-dismiss="modal">No</button>
</form><?php /**PATH C:\xampp\htdocs\voters_reg\resources\views/delete_resident.blade.php ENDPATH**/ ?>