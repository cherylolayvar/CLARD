<form autocomplete="off">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="container d-flex flex-row">
    <div class="pl-2 w-50">
      <?php echo csrf_field(); ?>
        <div class="form-group">
          <label for="recipient-name" class="col-form-label">Household No.:</label>
          <input type="text" id="edit_hn" class="form-control" value="<?php echo e($datas->household_no); ?>" id="household" required>
        </div>
        <div class="form-group">
            <label for="recipient-name" class="col-form-label">Fullname:</label>
            <input type="text" id="edit_fullname" class="form-control" id="fullname"  value="<?php echo e($datas->fullname); ?>" required>
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Birthdate:</label>
            <input type="date" id="edit_bdate" class="form-control" id="bdate"  value="<?php echo e($datas->bdate); ?>" required>
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Age:</label>
            <input type="number" id="edit_age" class="form-control"  value="<?php echo e($datas->age); ?>" id="age" required>
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Civil Status:</label>
            <select id="edit_civil" class="form-control" required>
             <?php $__currentLoopData = $civil_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $civil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($civil->civil_status); ?>" <?php echo e($datas->civil_status == $civil->civil_status ? 'selected':''); ?>><?php echo e($civil->civil_status); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <div class="form-group">
            <label for="recipient-name" class="col-form-label">Religion:</label>
            <input type="text" id="edit_religion" class="form-control"  value="<?php echo e($datas->religion); ?>" id="religion" required>
          </div>
    </div>
    <div class="pl-2 w-50">
      <div class="form-group">
        <label for="recipient-name" class="col-form-label">BirthPlace:</label>
        <input type="text" id="edit_bplace" class="form-control"  value="<?php echo e($datas->bplace); ?>" id="bplace" required>
      </div>
      <div class="form-group">
          <label for="recipient-name" class="col-form-label">Voter:</label>
          <select id="edit_voter" class="form-control" required>
            <?php $__currentLoopData = $voter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voters): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($voters->is_voters); ?>" <?php echo e($datas->voter == $voters->is_voters ? 'selected': ''); ?>><?php echo e($voters->is_voters); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <div class="form-group">
          <label for="recipient-name" class="col-form-label">Benefits:</label>
          <input type="text" id="edit_benefits" class="form-control"  value="<?php echo e($datas->benefits); ?>" id="benefits" required>
        </div>
        <div class="form-group">
          <label for="recipient-name" class="col-form-label">Annual:</label>
          <input type="number" id="edit_annual" class="form-control"  value="<?php echo e($datas->annual); ?>" id="annual" required>
        </div>
        <div class="form-group">
          <label for="recipient-name" class="col-form-label">Occupation:</label>
          <input type="text" id="edit_work" class="form-control"  value="<?php echo e($datas->work); ?>" id="occupation" required>
        </div>
        <div class="form-group">
          <label for="recipient-name" class="col-form-label">Status:</label>
          <select  id="edit_status" class="form-control" required >
            <<?php $__currentLoopData = $stat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($status->is_status); ?>" <?php echo e($datas->status == $status->is_status ? 'selected':''); ?>><?php echo e($status->is_status); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</form><?php /**PATH C:\xampp\htdocs\bms\resources\views/edit_resident.blade.php ENDPATH**/ ?>