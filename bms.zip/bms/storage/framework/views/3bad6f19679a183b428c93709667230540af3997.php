<?php $__env->startSection('content'); ?>
<div class="container">
       <table class="table mt-2 table-bordered">
        <thead class="thead-light">
          <tr>
            <th class="text-center">Names</th>
            <th class="text-center">Age</th>
            <th class="text-center">Designation</th>
            <th class="text-center">Job Position</th>
            <th class="text-center">Start Term</th>
            <th class="text-center">End Term</th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $official; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $officials): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <th class="text-center"><?php echo e($officials->fullname); ?></th>
              <td class="text-center"><?php echo e($officials->age); ?></td>
              <td class="text-center"><?php echo e($officials->designation); ?></td>
              <td class="text-center"><?php echo e($officials->job_position); ?></td>
              <td class="text-center"><?php echo e($officials->start_term); ?></td>
              <td class="text-center"><?php echo e($officials->end_term); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
      <div class="d-flex flex-row">
        <div class="card mt-1 mb-4 mx-4" style="width: 14rem; height:10rem;">
            <div class="card-body">
              <h5 class="card-title text-center mt-3">Total No. of Population</h5>
              <p class="card-text text-center text-danger font-weight-bold" style="font-size:1.5rem;"><?php echo e($countPopulation->count()); ?></p>
            </div>
          </div>
          <div class="card mt-1 mb-4 mx-4" style="width: 14rem; height:10rem;">
            <div class="card-body">
              <h5 class="card-title text-center mt-3">Total No. of Registered Voters</h5>
              <p class="card-text text-center text-danger font-weight-bold" style="font-size:1.5rem;"><?php echo e($countVoters->count()); ?></p>
            </div>
          </div>
          <div class="card mt-1 mb-42 mx-4" style="width: 14rem; height:10rem;">
            <div class="card-body">
              <h5 class="card-title text-center mt-3">Total No. of Senior Citizens</h5>
              <p class="card-text text-center text-danger font-weight-bold" style="font-size:1.5rem;"><?php echo e($countSeniors->count()); ?></p>
            </div>
          </div>
          <div class="card mt-1 mb-4 mx-4" style="width: 14rem; height:10rem;">
            <div class="card-body">
              <h5 class="card-title text-center mt-3">Total No. of Indigenous People</h5>
              <p class="card-text text-center text-danger font-weight-bold" style="font-size:1.5rem;"><?php echo e($countIndigent->count()); ?></p>
            </div>
          </div>
          <div class="card mt-1 mb-4 mx-4" style="width: 14rem; height:10rem;">
            <div class="card-body">
              <h5 class="card-title text-center mt-3">Total No. of Deceased</h5>
              <p class="card-text text-center text-danger font-weight-bold" style="font-size:1.5rem;"><?php echo e($countDeceased->count()); ?></p>
            </div>
          </div>
      </div>
      
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bms\resources\views/home.blade.php ENDPATH**/ ?>