

<?php $__env->startSection('content'); ?>
<form autocomplete="off">
<div class="container d-flex flex-row">
<div class="pl-2 w-50">
  <?php $__currentLoopData = $resident; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $getResident): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php echo csrf_field(); ?>
  <?php echo method_field('PUT'); ?>
    <div class="form-group">
      <input type="hidden" class="form-control" value="<?php echo e($getResident->id); ?>" id="updt_id" disabled>
      <label for="recipient-name" class="col-form-label">Household No.:</label>
      <input type="text" class="form-control" value="<?php echo e($getResident->household_no); ?>" id="updt_household" disabled>
    </div>
    <div class="form-group">
        <label for="recipient-name" class="col-form-label">Fullname:</label>
        <input type="text" class="form-control" value="<?php echo e($getResident->fullname); ?>" id="updt_fullname" disabled>
      </div>
      <div class="form-group">
        <label for="recipient-name" class="col-form-label">Birthdate:</label>
        <input type="date" class="form-control" value="<?php echo e($getResident->bdate); ?>" id="updt_bdate" disabled>
      </div>
      <div class="form-group">
        <label for="recipient-name" class="col-form-label">Age:</label>
        <input type="number" class="form-control" value="<?php echo e($getResident->age); ?>" id="updt_age" disabled>
      </div>
      <div class="form-group">
        <label for="recipient-name" class="col-form-label">Civil Status:</label>

        <select id="updt_civil" class="form-control" disabled>
          <?php $__currentLoopData = $civil_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $civil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option  value="<?php echo e($civil->civil_status); ?>" <?php echo e($getResident->civil_status == $civil->civil_status ? 'selected': ''); ?>><?php echo e($civil->civil_status); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="form-group">
        <label for="recipient-name" class="col-form-label">Religion:</label>
        <input type="text" class="form-control"  value="<?php echo e($getResident->religion); ?>" id="updt_religion" disabled>
      </div>
</div>
<div class="pl-2 w-50">
  <div class="form-group">
    <label for="recipient-name" class="col-form-label">BirthPlace:</label>
    <input type="text" class="form-control"  value="<?php echo e($getResident->bplace); ?>" id="updt_bplace" disabled>
  </div>
  <div class="form-group">
      <label for="recipient-name" class="col-form-label">Voter:</label>
      <select id="updt_voter" class="form-control" disabled>
        <?php $__currentLoopData = $voter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $voters): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($voters->is_voters); ?>" <?php echo e($getResident->voter == $voters->is_voters ? 'selected': ''); ?>><?php echo e($voters->is_voters); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
    </div>
    <div class="form-group">
      <label for="recipient-name" class="col-form-label">Benefits:</label>
      <input type="text" class="form-control"  value="<?php echo e($getResident->benefits); ?>" id="updt_benefits" disabled>
    </div>
    <div class="form-group">
      <label for="recipient-name" class="col-form-label">Annual:</label>
      <input type="number" class="form-control"  value="<?php echo e($getResident->annual); ?>" id="updt_annual" disabled>
    </div>
    <div class="form-group">
      <label for="recipient-name" class="col-form-label">Occupation:</label>
      <input type="text" class="form-control"  value="<?php echo e($getResident->work); ?>" id="updt_occupation" disabled>
    </div>
    <div class="form-group">
      <label for="recipient-name" class="col-form-label">Status:</label>
      <select  id="updt_status" class="form-control" disabled >
        <?php $__currentLoopData = $stat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($status->is_status); ?>" <?php echo e($getResident->status == $status->is_status ? 'selected':''); ?>><?php echo e($status->is_status); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>
  </div>
  <button id="btnDeleteResident" type="button" data-toggle="modal" data-target="#deleteResidentModal"  class="btn btn-danger mb-2" style="float:right;"><i class="fa fa-trash"></i>&nbsp;Delete Resident</button>
  <button id="btnEditResident" type="button" data-toggle="modal" data-target="#updateResidentModal"  class="btn btn-dark mb-2 mr-2" style="float:right;"><i class="fa fa-edit"></i>&nbsp;Edit Resident</button>
  <a href="/residents" id="btnAddRes" style="float: right;" class="text-white btn btn-primary mb-2 mr-2"><i class="fa fa-arrow-left"></i>&nbsp;View Resident List</a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</form>
<div>
<!-- Modal Update Resident -->
<div class="modal fade" id="updateResidentModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header bg-primary">
        <h5 class="modal-title text-white" id="exampleModalLongTitle"><i class="fa fa-user"></i>&nbsp;Update Resident</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="edit_data">
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        <button id="btnUpdateResident" type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
<!-- Modal Delete Resident -->
<div class="modal fade" id="deleteResidentModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
      <div class="modal-content">
      <div class="modal-header bg-primary">
        <h5 class="modal-title text-white" id="exampleModalLongTitle"><i class="fa fa-trash"></i>&nbsp;Confirm to Delete</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
          </button>
      </div>
      <div class="modal-body" id="delete_data">
      
      </div>
      </div>
  </div>
  </div>
</div>
  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bms\resources\views/show_resident.blade.php ENDPATH**/ ?>