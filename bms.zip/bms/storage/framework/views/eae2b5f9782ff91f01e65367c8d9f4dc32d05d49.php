

<?php $__env->startSection('content'); ?>
<div class="container-fluid mr-2">
       <a href="/residents/add" id="btnAddRes" style="float: right;" class="text-white btn btn-primary mb-2"><i class="fa fa-plus"></i>&nbsp;Add New Resident</a>
       <table class="table mt-2" id="tbl_residents">
        <thead class="thead-light">
          <tr>
            <th class="text-center">#</th>
            <th class="text-center">Household No.</th>
            <th class="text-center">Fullname</th>
            <th class="text-center">Birthdate</th>
            <th class="text-center">Age</th>
            <th class="text-center">Civil Status</th>
            <th class="text-center">Religion</th>
            <th class="text-center">BirthPlace</th>
            <th class="text-center">Registered Voter</th>
            <th class="text-center">Benefits</th>
            <th class="text-center">Annual</th>
            <th class="text-center">Work</th>
            <th class="text-center">Status</th>
            <th class="text-center">Action</th>
          </tr>
        </thead>
        <?php $__currentLoopData = $resident; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $residents): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
          <tr>
            <td class="text-center"><?php echo e($residents->id); ?></td>
            <td class="text-center"><?php echo e($residents->household_no); ?></td>
            <td class="text-center"><?php echo e($residents->fullname); ?></td>
            <td class="text-center"><?php echo e($residents->bdate); ?></td>
            <td class="text-center"><?php echo e($residents->age); ?></td>
            <td class="text-center"><?php echo e($residents->civil_status); ?></td>
            <td class="text-center"><?php echo e($residents->religion); ?></td>
            <td class="text-center"><?php echo e($residents->bplace); ?></td>
            <td class="text-center"><?php echo e($residents->voter); ?></td>
            <td class="text-center"><?php echo e($residents->benefits); ?></td>
            <td class="text-center"><?php echo e($residents->annual); ?></td>
            <td class="text-center"><?php echo e($residents->work); ?></td>
            <td class="text-center"><?php echo e($residents->status); ?></td>
            <td class="text-center">
              <a href="/residents/show/<?php echo e($residents->id); ?>"><i class="fa fa-upload text-default mr-3"  style="cursor: pointer;"></i></a>
            </td>
            
          </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>
</div>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\voters_reg\resources\views/residents.blade.php ENDPATH**/ ?>