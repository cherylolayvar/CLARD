<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Barangay Infomation Management System</title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-dark shadow-sm" style="background-color:#116BCA;">
            <div class="container-fluid">
                <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                   BMS Software
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="nav-link text-white" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link text-white" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item">
                                <a class="nav-link text-white" href="<?php echo e(route('dashboard')); ?>" id="dasboard"><?php echo e(__('Dashboard')); ?></a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link text-white" href="<?php echo e(route('residents')); ?>" id="residents"><?php echo e(__("Residents")); ?></a>
                            </li>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle text-white" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
        <main class="py-5" style="height: 100vh; background:#E1F0FF;" id="main">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
</html>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
  $(document).ready(function(){
    $(document).on('click', '#btnSaveResident', ()=>{
        household = $('#household').val();
        fullname = $('#fullname').val();
        bdate = $('#bdate').val();
        age = $('#age').val();
        civil = $('#civil').val();
        religion = $('#religion').val();
        bplace = $('#bplace').val();
        voter = $('#voter').val();
        benefits = $('#benefits').val();
        annual = $('#annual').val();
        work = $('#occupation').val();
        status = $('#status').val();

        if(household != "" && fullname !='' && age !='' &&civil !='' && religion !='' && bplace !='' && voter !='' && benefits !='' && annual !='' && work !=''&& status !=''){
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            })   
            $.ajax({
                url:'/residents/save',
                method: 'POST',
                cache: false,
                data:{
                    household:household,
                    fullname:fullname,
                    bdate:bdate,
                    age:age,
                    civil:civil,
                    religion:religion,
                    bplace:bplace,
                    voter:voter,
                    benefits:benefits,
                    annual:annual,
                    work:work,
                    status:status
                },
                success: function(data){
                    alert(data);
                    window.location = "/residents/add";
                }
            })
        }else{
            alert('All Fields are Required');
        }
        
    })
    $(document).on('click','#btnEditResident',()=>{
        id = $('#updt_id').val();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        }) 
        $.ajax({
            url:'/residents/edit/'+id,
            method:'GET',
            cache:false,
            data:'',
            success: function(data){
                $('#edit_data').html(data);
            }
        })
    })
    $(document).on('click','#btnUpdateResident',()=>{
        id = $('#updt_id').val();
        household = $('#edit_hn').val();
        fullname = $('#edit_fullname').val();
        bdate = $('#edit_bdate').val();
        age = $('#edit_age').val();
        civil = $('#edit_civil').val();
        religion = $('#edit_religion').val();
        bplace = $('#edit_bplace').val();
        voter = $('#edit_voter').val();
        benefits = $('#edit_benefits').val();
        annual = $('#edit_annual').val();
        work = $('#edit_work').val();
        status = $('#edit_status').val();
        
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        }) 
        $.ajax({
            url:'/residents/update',
            method:'PUT',
            cache:false,
            data:{
                    household:household,
                    fullname:fullname,
                    bdate:bdate,
                    age:age,
                    civil:civil,
                    religion:religion,
                    bplace:bplace,
                    voter:voter,
                    benefits:benefits,
                    annual:annual,
                    work:work,
                    status:status,
                    id:id
            },
            success: function(data){
                alert(data);
                window.location = "/residents";
            }
        })
    })
    $(document).on('click','#btnDeleteResident',()=>{
        id = $('#updt_id').val();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        }) 
        $.ajax({
            url:'/residents/delete/'+id,
            method:'GET',
            cache:false,
            data:'',
            success: function(data){
               $('#delete_data').html(data);
            }
        })
    })
    $(document).on('click','#btnConfirmDeleteResident',()=>{
        id = $('#delete_id').val();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        }) 
        $.ajax({
            url:'/residents/confirm-delete',
            method:'DELETE',
            cache:false,
            data:{id:id},
            success: function(data){
               alert(data);
               window.location = "/residents";
            }
        })
    })
  })
</script>


<?php /**PATH C:\xampp\htdocs\voters_reg\resources\views/layouts/app.blade.php ENDPATH**/ ?>