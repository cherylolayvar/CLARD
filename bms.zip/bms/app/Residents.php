<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Residents extends Model
{
    protected $fillable = [
           'household_no',
           'fullname',
           'bdate',
           'age',
           'civil_status',
           'religion',
           'bplace',
           'voter',
           'benefits',
           'annual',
           'work',
           'status',
        ];


    public $timestamps = false;
}
