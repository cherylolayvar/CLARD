<?php

namespace App\Http\Controllers;

use App\Residents;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;



class residentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $residents = DB::select('Select * from residents');
        return view('residents', ['resident'=>$residents]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('add_resident');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $residents = new Residents();
        $residents->household_no = $request->household;
        $residents->fullname = $request->fullname;
        $residents->bdate = $request->bdate;
        $residents->age = $request->age;
        $residents->civil_status = $request->civil;
        $residents->religion = $request->religion;
        $residents->bplace = $request->bplace;
        $residents->voter = $request->voter;
        $residents->benefits = $request->benefits;
        $residents->annual = $request->annual;
        $residents->work = $request->work;
        $residents->status = $request->status;

        $residents->save();

        return 'Data Has Been Saved.';
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $civil_status = DB::select("Select * from civil__statuses");
        $voters = DB::select("Select * from voters");
        $status = DB::select("Select * from status");
        $getResident = DB::select("Select * from residents where id = '".$id."'");
        return view('show_resident', ['resident'=>$getResident, 'civil_status'=>$civil_status,'voter'=>$voters,'stat'=>$status]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
         $civil_status = DB::select("Select * from civil__statuses");
         $voters = DB::select("Select * from voters");
         $status = DB::select("Select * from status");
        $getResident = DB::select("Select * from residents where id = '".$id."'");
        return view('edit_resident', ['data'=>$getResident,'civil_status'=>$civil_status,'voter'=>$voters,'stat'=>$status]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $data = Residents::find($request->id);
        $data->household_no = $request->household;
        $data->fullname = $request->fullname;
        $data->bdate = $request->bdate;
        $data->age = $request->age;
        $data->civil_status = $request->civil;
        $data->religion = $request->religion;
        $data->bplace = $request->bplace;
        $data->voter = $request->voter;
        $data->benefits = $request->benefits;
        $data->annual = $request->annual;
        $data->work = $request->work;
        $data->status = $request->status;
        $data->save();

        return 'Data Has Been Saved.';

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function deleteById($id)
    {      
        return view('delete_resident',['id'=>$id]);
    }

     /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function confirmDelete(Request $request)
    {
        $deleteResident = Residents::find($request->id);
        $deleteResident->delete();

        return 'Data Has been Deleted';

    }
}
